package com.Micro.demo.Service;

import com.Micro.demo.Request.TeamRequest;
import com.Micro.demo.ResponseDTO.EmployeeDTO;
import com.Micro.demo.ResponseDTO.ProjectDTO;
import com.Micro.demo.ResponseDTO.TeamDTO;
import com.Micro.demo.Entity.Employee;
import com.Micro.demo.Entity.Project;
import com.Micro.demo.Entity.Team;

import java.util.List;

public interface ServiceClass {



    public TeamDTO InsertAllService(TeamRequest teamRequest);

    public Project insertEmployeeForTheSameTeam(String projectName, List<Employee> employees);

    public List<TeamDTO> GetAllDetails();

    public EmployeeDTO GetByIdEmployeeService(Long emplID);

    public Team UpdateTeamService(Team team, Long id);

    public Employee updateEmployeeService(Long id, Employee employee);

    public Project updateProjectService(Project project, Long id);

    public void updateEmployeeIsExists(Long id);

    //public Object MoveEmployee(Long empId, Long ProjId);
    public List<Employee> MoveEmployee(List<Employee> employeeList , Long projId) ;
}

