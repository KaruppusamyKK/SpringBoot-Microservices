package com.Micro.demo.Repo;

import com.Micro.demo.Entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface EmpRepo extends JpaRepository<Employee,Long> {


 public List<Employee> findByEmpUniqueId(Long id);


    public boolean  existsByEmpUniqueId(Long id);

        @Modifying
        @Query(value = "UPDATE employee SET employee_is_exists = 0 WHERE emplid = :id", nativeQuery = true)
        void setEmployeeIsExistsToFalse(@Param("id") Long id);



}
