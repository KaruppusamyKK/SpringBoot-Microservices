package com.Micro.demo.ResponseDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.ArrayList;
import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectDTO {


    private String projName;
    private String projBudget;
    private List<EmployeeDTO> employeeList = new ArrayList<>();
}
