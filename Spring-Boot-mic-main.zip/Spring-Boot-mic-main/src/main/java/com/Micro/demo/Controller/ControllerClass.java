package com.Micro.demo.Controller;
import com.Micro.demo.Request.TeamRequest;
import com.Micro.demo.ResponseDTO.EmployeeDTO;
import com.Micro.demo.ResponseDTO.TeamDTO;
import com.Micro.demo.Entity.Employee;
import com.Micro.demo.Entity.Project;
import com.Micro.demo.Entity.Team;
import com.Micro.demo.Repo.EmpRepo;
import com.Micro.demo.Repo.PrJRepo;
import com.Micro.demo.Repo.TeamRepo;
import com.Micro.demo.ResponseHandler.Response;
import com.Micro.demo.ServiceImpl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController
public class ControllerClass {
    @Autowired
    ServiceImpl serviceImpl;
    @Autowired
    TeamRepo teamRepo;
    @Autowired
    PrJRepo projRepo;
    @Autowired
    EmpRepo empRepo;


    //insert all
//    @PostMapping("/insertAll")
//    public ResponseEntity<Response> insertAllController(@RequestBody Team team) {
//    Team teamObj=serviceImpl.InsertAllService(team);
//    String message="sucess , Total Employee available are  :"
//           +team.getProject().
//            getEmployeeList().
//            size();
//    Response successResponse= new Response(HttpStatus.ACCEPTED.value(),message,teamObj,null,null,null,null);
//    return  ResponseEntity.status(HttpStatus.ACCEPTED).body(successResponse);
//    }

//    @PostMapping("/insertAll")
//    public ResponseEntity<Response> insertAllController(@RequestBody Team team) {
//        Team teamObj=serviceImpl.InsertAllService(team);
//        String message="sucess , Total Employee available are  :"
//                +team.getProject().
//                getEmployeeList().
//                size();
//        Response successResponse= new Response(HttpStatus.ACCEPTED.value(),message,teamObj,null,null,null,null);
//        return  ResponseEntity.status(HttpStatus.ACCEPTED).body(successResponse);
//    }


    @PostMapping("/insertAll")
    public ResponseEntity<Response> insertAllController(@RequestBody TeamRequest teamRequest) {
        TeamDTO teamObj=serviceImpl.InsertAllService(teamRequest);
        String message="sucess , Total Employee available are  :"
                +teamRequest.getTeam().getProject().
                getEmployeeList().
                size();
        Response successResponse= new Response(HttpStatus.ACCEPTED.value(),message,teamObj,null,null,null,null);
        return  ResponseEntity.status(HttpStatus.ACCEPTED).body(successResponse);
    }


    //insert more employee
    @PostMapping("/addMoreEmployee/{name}")
    public ResponseEntity<Response> insertEmployeeForTheSameTeamController(
             @PathVariable String name,
             @RequestBody List<Employee> employees) {
    String message="updated employess successfully, total employees updated :"+ employees.size();
    Response SuccessResponse=new Response(HttpStatus.ACCEPTED.value(),message,null, serviceImpl.insertEmployeeForTheSameTeam(name, employees), null, null,null);
    return ResponseEntity.status(HttpStatus.ACCEPTED).body(SuccessResponse);
    }

    //get all
    @GetMapping("/GetAll")
    public ResponseEntity<Map<String,Object>> GetAllDetailsController() {
    List<TeamDTO> teamList=serviceImpl.GetAllDetails();
    int employeeSizee=empRepo.findAll().size();
    int teamSize=teamList.size();
            Map<String, Object> response = new LinkedHashMap<>();
            response.put("status", HttpStatus.OK.value());
            response.put("Team", "Success, total teams :"+teamSize);
            response.put("Employee","success, total employee : "+employeeSizee);
            response.put("data", serviceImpl.GetAllDetails());
    return ResponseEntity.ok(response);
    }



    //get employee by id
    @GetMapping("/employee/{id}")
    public EmployeeDTO GetByIdEmployeeController(@PathVariable("id") Long id) {
    return serviceImpl.GetByIdEmployeeService(id);
    }


    //update team
    @PutMapping("/team/update/{id}")
    public Team updateTeamController(@RequestBody Team team, @PathVariable Long id) {
    return serviceImpl.UpdateTeamService(team, id);
    }


    //update employee
    @PutMapping("/employee/{id}")
    public Employee updateEmployeeController(@PathVariable Long id,@RequestBody Employee employee) {
    return serviceImpl.updateEmployeeService(id, employee);
    }


    //-update project
    @PutMapping("/project/update/{id}")
    public Project updateProjectController(@RequestBody Project project, @PathVariable Long id) {
    return serviceImpl.updateProjectService(project,id);
    }


    //soft delete
    @PatchMapping("/{id}")
    public void DeleteEmployeeController(@PathVariable Long id) {
        serviceImpl.updateEmployeeIsExists(id);
    }

    //move
    @PutMapping("move/employeeList/{projId}")
    public ResponseEntity<Map<String,Object>> MoveEmployeeController(@RequestBody List<Employee> employeeList ,
            @PathVariable Long projId )
    {
            Map<String, Object> response = new LinkedHashMap<>();
            response.put("status", HttpStatus.OK.value());
            response.put("message", "Success");
            response.put("data", serviceImpl.MoveEmployee(employeeList, projId));
            return ResponseEntity.ok(response);
    }
}




