package com.Micro.demo.Entity;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Team {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;
    private String teamName;
    private String teamLead;
    @JsonManagedReference
    @OneToOne(mappedBy = "team",cascade = CascadeType.PERSIST )
    private Project project;

}
