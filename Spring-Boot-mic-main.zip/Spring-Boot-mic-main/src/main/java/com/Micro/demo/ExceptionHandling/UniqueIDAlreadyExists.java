package com.Micro.demo.ExceptionHandling;

public class UniqueIDAlreadyExists extends RuntimeException{
    public UniqueIDAlreadyExists() {
    }

    public UniqueIDAlreadyExists(String message) {
        super(message);
    }
}
