package com.Micro.demo.ServiceImpl;
import com.Micro.demo.Request.TeamRequest;
import com.Micro.demo.ResponseDTO.EmployeeDTO;
import com.Micro.demo.ResponseDTO.ProjectDTO;
import com.Micro.demo.ResponseDTO.TeamDTO;
import com.Micro.demo.Entity.Employee;
import com.Micro.demo.Entity.Project;
import com.Micro.demo.Entity.Team;
import com.Micro.demo.ExceptionHandling.EmployeeNotFoundException;
import com.Micro.demo.ExceptionHandling.TeamNotExists;
import com.Micro.demo.ExceptionHandling.UniqueIDAlreadyExists;
import com.Micro.demo.Repo.EmpRepo;
import com.Micro.demo.Repo.PrJRepo;
import com.Micro.demo.Repo.TeamRepo;
import com.Micro.demo.Service.ServiceClass;
import jakarta.persistence.Table;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ServiceImpl implements ServiceClass {
    @Autowired
    EmpRepo empRepo;
    @Autowired
    TeamRepo teamRepo;
    @Autowired
    PrJRepo projRepo;


    public  TeamDTO TeamDTOentityToDTO(Team team) {
    TeamDTO teamDTO = new TeamDTO();
    teamDTO.setTeamName(team.getTeamName());
    teamDTO.setTeamLead(team.getTeamLead());
    ProjectDTO projectDTO = new ProjectDTO();
    projectDTO.setProjName(team.getProject().getProjName());
    projectDTO.setProjBudget(team.getProject().getProjBudget());
    teamDTO.setProject(projectDTO);
                List<EmployeeDTO> employeeDTOListTemp=new ArrayList<>();
                for (Employee employee: team.getProject().getEmployeeList()) {
                EmployeeDTO employeeDTO=new EmployeeDTO();
                employeeDTO.setEmplName(employee.getEmplName());
                employeeDTO.setEmpUniqueId(employee.getEmpUniqueId());
                employeeDTOListTemp.add(employeeDTO);
                }
        teamDTO.getProject().setEmployeeList(employeeDTOListTemp);
        return teamDTO;
        }

    public  ProjectDTO ProjectDTOentityToDTO(Project project) {
    ProjectDTO projectDTO=new ProjectDTO();
    projectDTO.setProjName(project.getProjName());
    projectDTO.setProjBudget(project.getProjBudget());
            List<EmployeeDTO> employeeDTOListTemp=new ArrayList<>();
            for (Employee employee: project.getEmployeeList()) {
            EmployeeDTO employeeDTO=new EmployeeDTO();
            employeeDTO.setEmplName(employee.getEmplName());
            employeeDTO.setEmpUniqueId(employee.getEmpUniqueId());
            employeeDTOListTemp.add(employeeDTO);
            }
     projectDTO.setEmployeeList(employeeDTOListTemp);
     return projectDTO;
     }


    public  EmployeeDTO EmployeeDTOentityToDTO(Employee employee) {
    EmployeeDTO employeeDTO=new EmployeeDTO();
    employeeDTO.setEmplName(employee.getEmplName());
    employeeDTO.setEmpUniqueId(employee.getEmpUniqueId());
    return employeeDTO;

    }

    @Override
    public TeamDTO InsertAllService(TeamRequest teamRequest) {
        Team team=teamRequest.getTeam();
    Project project = team.getProject();
            if (project != null && project.getEmployeeList() != null)
            {
            for (Employee employee : project.getEmployeeList())
            {
            Boolean optionalEmployee = empRepo.existsByEmpUniqueId(employee.getEmpUniqueId());
            if (optionalEmployee) {
            throw new UniqueIDAlreadyExists("Employee exists in the Db with Unique id: " + employee.getEmpUniqueId());
            }
            }
    }
    return TeamDTOentityToDTO(teamRepo.save(team));
    }


    @Override
    public EmployeeDTO GetByIdEmployeeService(Long id) {
    if (empRepo.findById(id).isEmpty())
    throw new EmployeeNotFoundException("not exeists");
    return EmployeeDTOentityToDTO(empRepo.findById(id).get());    }


//    @Override
//    public List<Team> GetAllDetails() {
//    return teamRepo.findAll();
//    }

    @Override
    public List<TeamDTO> GetAllDetails() {
    List<Team> teams=teamRepo.findAll();
    List<TeamDTO> teamDTOS=new ArrayList<>();
    for (Team team: teams)
    {
        teamDTOS.add(TeamDTOentityToDTO(team));
    }
    return teamDTOS;
}

    @Override
    public Team UpdateTeamService(Team team, Long id) {
    team.setId(id);
    return teamRepo.save(team);
    }


    @Override
    public Project insertEmployeeForTheSameTeam(String projectName, List<Employee> employees) {
    Project project = projRepo.findByprojName(projectName);
    if (project == null) {
    throw new TeamNotExists("not found");
    }
//    for (Employee employee : employees) {
//    List<Employee> existingEmployees = empRepo.findByEmpUniqueId(employee.getEmpUniqueId());
//    if (!existingEmployees.isEmpty()) {
//    throw new UniqueIDAlreadyExists("The id already exists in DB");
//    }
//    project.getEmployeeList().add(employee);
//    employee.setProject(project);
//     }
    employees.stream().forEach(employee ->
        {
            List<Employee> existingEmployees = empRepo.findByEmpUniqueId(employee.getEmpUniqueId());
            if (!existingEmployees.isEmpty()) {
    throw new UniqueIDAlreadyExists("The id already exists in DB");
    }
    project.getEmployeeList().add(employee);
    employee.setProject(project);
        });
    return projRepo.save(project);
    }


    @Transactional
    @Override
    public void updateEmployeeIsExists(Long id) {
    if (empRepo.findById(id).isPresent()) {
    empRepo.setEmployeeIsExistsToFalse(id);
    return;
    }
    throw new EmployeeNotFoundException("ID " + id + " doesn't exists in DB");
    }

    @Override
    public Employee updateEmployeeService(Long id, Employee employee) {
    Optional <Employee> employee1=empRepo.findById(id);
    if (employee1.isPresent())
    {
    employee.setEmplID(id);
    }
    return empRepo.save(employee);
    }

    @Override
    public Project updateProjectService(Project project, Long id) {
    System.out.println(id.toString());
    Optional<Project> project1=projRepo.findById(id);
    if (project1.isPresent())
    {

            Project existing=project1.get();
            existing.setProjName(project.getProjName());
            existing.setProjBudget(project.getProjBudget());
            return projRepo.save(existing);
    }
    else
    {
    throw new EmployeeNotFoundException("Not found");
    }
    }

//    @Transactional
//    public Object MoveEmployee(Long empId, Long projId) {
//        // Fetch the existing employee
    //        Employee employee = empRepo.findById(empId).get();
//        Project newProject = projRepo.findById(projId).get();
//        Long originalUniqueValue = employee.getEmpUniqueId(); // 10
//        employee.setEmpUniqueId(0L); // set to 0 in old
//        empRepo.save(employee); // save in old
//        employee.setProject(newProject); // set to project
//        employee.setEmpUniqueId(originalUniqueValue); //back to original
//        return  empRepo.save(employee); //save
//
//    }
    @Transactional
    public List<Employee> MoveEmployee(List<Employee> employeeList , Long projId) {
    Optional<Project> newProject = projRepo.findById(projId);
        if (!newProject.isPresent())
        {
            throw new EmployeeNotFoundException("The id "+projId+ "is not present");
        }

    List<Employee> tempList=new ArrayList<>();
        for (Employee employeeLoop : employeeList)
    {
            Long originalUniqueValue = employeeLoop.getEmpUniqueId();  //10
            employeeLoop.setEmpUniqueId(0L);   //0
            tempList.add(empRepo.save(employeeLoop));

//0
//save
//set ---> prj
// 0---> 100
//save
            employeeLoop.setProject(newProject.get()); // move / set
            employeeLoop.setEmpUniqueId(originalUniqueValue);
            tempList.add(empRepo.save(employeeLoop));
     }
     return tempList;

    }

}
