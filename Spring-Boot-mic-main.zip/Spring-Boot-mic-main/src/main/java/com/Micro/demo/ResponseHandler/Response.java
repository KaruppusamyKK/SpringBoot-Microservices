package com.Micro.demo.ResponseHandler;

import com.Micro.demo.Entity.Employee;
import com.Micro.demo.Entity.Project;
import com.Micro.demo.Entity.Team;
import com.Micro.demo.ResponseDTO.EmployeeDTO;
import com.Micro.demo.ResponseDTO.ProjectDTO;
import com.Micro.demo.ResponseDTO.TeamDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Response {

    private int responseCode;
    private String responseMessage;
    private TeamDTO team;
    private Project projectDTO;
    private EmployeeDTO employeeDTO;
    private List<Employee> employeeList;
    private List<Team> teamList;
    }



