package com.Micro.demo.Entity;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long emplID;
    private Long empUniqueId;
    private String emplName;
    private int emplAge;
    @Column(name = "EmployeeIsExists")
    private int EmployeeIsExists=1;

    @JsonBackReference
    //@ManyToOne(cascade = CascadeType.PERSIST) old one if any error change back
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "prj_fk", nullable = false,referencedColumnName = "projId")
    Project project;


}
